const express = require('express')
const connectDB = require('./config/db')
const marketplaceRoutes = require('./routes/marketplaceRoutes')
const cors = require('cors') // Import CORS package
require('dotenv').config()

const app = express()

// Connect to MongoDB
connectDB()

// Middleware
app.use(
  cors({
    origin: 'http://localhost:3000', // Replace with your frontend URL
  })
) // Enable CORS for the frontend URL
app.use(express.json()) // Parse incoming JSON requests

// Routes
app.use('/api/marketplace', marketplaceRoutes)

// Error handling middleware
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res
      .status(400)
      .json({ success: false, message: 'Invalid JSON payload' })
  }
  console.error(err.stack)
  res.status(500).json({
    success: false,
    message: 'An internal server error occurred',
    error: err.message,
  })
})

// Start the server
const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`)
})
